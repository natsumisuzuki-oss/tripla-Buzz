# tripla Buzz パートナー登録 LP

旅好きインフルエンサー向けの成果報酬型アフィリエイト「tripla Buzz」パートナー登録ランディングページです。

## ファイル構成

```
triplabuzz-lp/
├── index.html        … ページ本体（マークアップ）
├── css/
│   └── style.css     … スタイル（配色・レイアウト・アニメーション）
├── js/
│   └── main.js       … スクロール連動のフェードイン演出
└── README.md
```

- ロゴはインラインSVGのため画像ファイル不要
- フォントは Google Fonts（Zen Maru Gothic / Plus Jakarta Sans）をCDN読み込み
- 外部ライブラリへの依存なし

## ローカルで確認する

`index.html` をブラウザで開くだけで表示できます。

## GitHub Pages で公開する

1. このフォルダの中身（`index.html` / `css/` / `js/`）をリポジトリ直下に置いて push
2. リポジトリの **Settings → Pages** を開く
3. **Source** を `Deploy from a branch`、ブランチを `main` / `(root)` に設定して保存
4. 数分後に `https://<ユーザー名>.github.io/<リポジトリ名>/` で公開されます


## 言語切替（日本語／English）

ヘッダー右の言語ボタンで日本語と英語を切り替えられます。翻訳テキストは `js/main.js` 内の `i18n.en` にまとまっているので、文言の調整はそこを編集してください。日本語側は `index.html` の各要素（`data-i18n` 属性付き）がそのまま使われます。

## 公開前のカスタマイズ

- `〈例〉` と書かれた箇所（報酬シミュレーションの数値など）を実数に差し替える
- CTAボタンのリンク先 `href="#"` を、実際の登録フォームURLに変更する
- 計測タグ（GA4・コンバージョンタグ）が必要な場合は `index.html` の `</head>` 直前などに追加する
